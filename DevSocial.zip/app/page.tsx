"use client"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, Code2, GitBranch, Zap } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10">
      <nav className="border-b border-border/50 bg-background/80 backdrop-blur">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-primary-foreground font-bold text-sm">
              DM
            </div>
            <span className="font-bold text-lg">DevMatch</span>
          </div>
          <div className="flex gap-4">
            <Link href="/login">
              <Button variant="ghost">Sign In</Button>
            </Link>
            <Link href="/signup">
              <Button>Get Started</Button>
            </Link>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold text-balance">Where Developers Build Together</h1>
            <p className="text-xl text-muted-foreground text-balance">
              Share your code, collaborate on projects, showcase your portfolio, and accelerate your tech career on
              DevMatch.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/signup">
              <Button size="lg" className="gap-2">
                Start Coding <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link href="/login">
              <Button size="lg" variant="outline">
                Sign In
              </Button>
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Code2 className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Share & Collaborate</h3>
              <p className="text-sm text-muted-foreground">
                Post code snippets, projects, and ideas. Get feedback from fellow developers instantly.
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                <GitBranch className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-lg font-semibold">Build Your Portfolio</h3>
              <p className="text-sm text-muted-foreground">
                Showcase your best work and let your code speak for itself
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Zap className="w-6 h-6 text-secondary" />
              </div>
              <h3 className="text-lg font-semibold">Accelerate Your Career</h3>
              <p className="text-sm text-muted-foreground">
                Land opportunities by connecting with teams and mentors in tech
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
