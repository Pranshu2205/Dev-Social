"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { ArrowLeft, Download, Eye, Plus, Trash2 } from "lucide-react"

export default function ResumeBuilder() {
  const [resumes, setResumes] = useState([
    {
      id: 1,
      name: "Senior Developer Resume",
      lastUpdated: "2 days ago",
      data: {
        fullName: "John Doe",
        email: "john@example.com",
        phone: "+1 (555) 123-4567",
      },
    },
  ])

  const [editingId, setEditingId] = useState<number | null>(null)
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    summary: "",
    experience: "",
    education: "",
    skills: "",
  })

  const handleNewResume = () => {
    setFormData({
      fullName: "",
      email: "",
      phone: "",
      summary: "",
      experience: "",
      education: "",
      skills: "",
    })
    setEditingId(-1)
  }

  const handleSave = () => {
    if (editingId === -1) {
      const newResume = {
        id: resumes.length + 1,
        name: formData.fullName || "Untitled Resume",
        lastUpdated: "just now",
        data: formData,
      }
      setResumes([newResume, ...resumes])
    }
    setEditingId(null)
  }

  const handleDelete = (id: number) => {
    setResumes(resumes.filter((r) => r.id !== id))
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card/50 backdrop-blur sticky top-0">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/feed" className="flex items-center gap-2 text-primary hover:underline">
            <ArrowLeft className="w-4 h-4" /> Back to Feed
          </Link>
          <h1 className="text-2xl font-bold">Resume Builder</h1>
          <div className="w-16" />
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {editingId === null ? (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Your Resumes</h2>
              <Button onClick={handleNewResume} className="gap-2">
                <Plus className="w-4 h-4" /> Create New
              </Button>
            </div>

            <div className="grid gap-4">
              {resumes.map((resume) => (
                <div
                  key={resume.id}
                  className="bg-card border border-border rounded-lg p-6 flex items-center justify-between hover:border-border/80 transition-colors"
                >
                  <div>
                    <h3 className="font-semibold text-lg">{resume.name}</h3>
                    <p className="text-sm text-muted-foreground">Updated {resume.lastUpdated}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setFormData(resume.data)
                        setEditingId(resume.id)
                      }}
                    >
                      Edit
                    </Button>
                    <Button variant="ghost" size="sm" className="gap-1">
                      <Eye className="w-4 h-4" /> Preview
                    </Button>
                    <Button variant="ghost" size="sm" className="gap-1">
                      <Download className="w-4 h-4" /> Download
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive"
                      onClick={() => handleDelete(resume.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-6">{editingId === -1 ? "Create New Resume" : "Edit Resume"}</h2>

            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Full Name</label>
                <Input
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  placeholder="John Doe"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <Input
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="john@example.com"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Phone</label>
                <Input
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+1 (555) 123-4567"
                />
              </div>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Professional Summary</label>
                <textarea
                  value={formData.summary}
                  onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                  placeholder="Write a brief summary..."
                  className="w-full min-h-24 p-3 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Experience</label>
                <textarea
                  value={formData.experience}
                  onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                  placeholder="List your work experience..."
                  className="w-full min-h-24 p-3 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Education</label>
                <textarea
                  value={formData.education}
                  onChange={(e) => setFormData({ ...formData, education: e.target.value })}
                  placeholder="List your education..."
                  className="w-full min-h-24 p-3 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Skills</label>
                <textarea
                  value={formData.skills}
                  onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
                  placeholder="List your skills..."
                  className="w-full min-h-24 p-3 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                />
              </div>
            </div>

            <div className="flex gap-4 mt-8">
              <Button onClick={handleSave} className="flex-1">
                Save Resume
              </Button>
              <Button variant="outline" onClick={() => setEditingId(null)} className="flex-1">
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
