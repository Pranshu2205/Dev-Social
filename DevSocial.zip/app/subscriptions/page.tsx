"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft, Check } from "lucide-react"

export default function Subscriptions() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("monthly")
  const [currentPlan, setCurrentPlan] = useState<"free" | "pro" | "enterprise">("free")

  const plans = [
    {
      id: "free",
      name: "Free",
      price: 0,
      description: "Perfect for getting started",
      features: [
        "Create up to 3 posts per month",
        "1 resume template",
        "Basic analytics",
        "Limited profile customization",
      ],
    },
    {
      id: "pro",
      name: "Pro",
      price: billingCycle === "monthly" ? 9.99 : 99.99,
      cycle: billingCycle === "monthly" ? "/month" : "/year",
      savings: billingCycle === "annual" ? "Save 17%" : undefined,
      description: "For professionals",
      features: [
        "Unlimited posts with rate limiting",
        "Unlimited resume templates",
        "Advanced analytics",
        "Profile verification",
        "Priority support",
        "Custom domain for resume",
      ],
    },
    {
      id: "enterprise",
      name: "Enterprise",
      price: "Custom",
      description: "For teams and organizations",
      features: [
        "Everything in Pro",
        "Team management",
        "Advanced security",
        "API access",
        "Dedicated account manager",
        "Custom integrations",
      ],
    },
  ]

  const handleUpgrade = (planId: string) => {
    if (planId === "enterprise") {
      alert("Enterprise plan: Contact sales for custom pricing")
      return
    }
    setCurrentPlan(planId as any)
    alert(`Upgraded to ${planId.toUpperCase()} plan!`)
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card/50 backdrop-blur sticky top-0">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center">
          <Link href="/feed" className="flex items-center gap-2 text-primary hover:underline">
            <ArrowLeft className="w-4 h-4" /> Back to Feed
          </Link>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        <div className="text-center space-y-4 mb-12">
          <h1 className="text-4xl font-bold">Choose Your Plan</h1>
          <p className="text-lg text-muted-foreground">
            Unlock premium features to accelerate your professional growth
          </p>
        </div>

        {/* Billing Toggle */}
        <div className="flex justify-center mb-12">
          <div className="bg-muted rounded-lg p-1 flex gap-1 inline-flex">
            <button
              onClick={() => setBillingCycle("monthly")}
              className={`px-6 py-2 rounded font-medium transition-colors ${
                billingCycle === "monthly"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle("annual")}
              className={`px-6 py-2 rounded font-medium transition-colors ${
                billingCycle === "annual"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Annual
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`rounded-xl border transition-all ${
                currentPlan === plan.id
                  ? "border-primary bg-primary/5 shadow-lg"
                  : "border-border hover:border-border/80"
              }`}
            >
              {plan.savings && (
                <div className="bg-accent text-accent-foreground px-4 py-1 rounded-t-xl text-center text-sm font-semibold">
                  {plan.savings}
                </div>
              )}

              <div className="p-6 space-y-6">
                <div>
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground">{plan.description}</p>
                </div>

                <div>
                  <div className="flex items-baseline gap-1">
                    {typeof plan.price === "number" ? (
                      <>
                        <span className="text-4xl font-bold">${plan.price}</span>
                        <span className="text-muted-foreground">{plan.cycle}</span>
                      </>
                    ) : (
                      <span className="text-4xl font-bold">{plan.price}</span>
                    )}
                  </div>
                </div>

                <Button
                  onClick={() => handleUpgrade(plan.id)}
                  className="w-full"
                  variant={currentPlan === plan.id ? "default" : "outline"}
                >
                  {currentPlan === plan.id ? "Current Plan" : "Upgrade"}
                </Button>

                <ul className="space-y-3">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex gap-3 text-sm">
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-16 max-w-2xl mx-auto space-y-6">
          <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>

          <div className="space-y-4">
            {[
              {
                q: "Can I change my plan anytime?",
                a: "Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.",
              },
              {
                q: "What payment methods do you accept?",
                a: "We accept all major credit cards, PayPal, and bank transfers for enterprise plans.",
              },
              {
                q: "Is there a free trial?",
                a: "Yes! The Free plan is essentially our free trial with limited features.",
              },
              {
                q: "Do you offer refunds?",
                a: "We offer a 30-day money-back guarantee for annual subscriptions.",
              },
            ].map((item, i) => (
              <div key={i} className="bg-card border border-border rounded-lg p-4">
                <h4 className="font-semibold mb-2">{item.q}</h4>
                <p className="text-sm text-muted-foreground">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
