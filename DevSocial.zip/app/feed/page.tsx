"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Heart, MessageCircle, Share2, Search, Home, FileText, Settings, LogOut, Plus, Globe, Zap } from "lucide-react"

export default function Feed() {
  const router = useRouter()
  const [posts, setPosts] = useState([
    {
      id: 1,
      author: "Sarah Chen",
      avatar: "👩‍💻",
      title: "Full Stack Developer | React & Node.js",
      content:
        "Just open-sourced my new React UI library! Built with TypeScript and Tailwind CSS. Check out the GitHub repo - PRs and feedback welcome!",
      timestamp: "2 hours ago",
      likes: 234,
      comments: 18,
      liked: false,
    },
    {
      id: 2,
      author: "Alex Rodriguez",
      avatar: "👨‍💻",
      title: "Backend Engineer | Go & Kubernetes",
      content:
        "Migrated our entire infrastructure to Kubernetes. Performance improved 60%, and deployment time dropped from 2 hours to 5 minutes. Happy to answer questions!",
      timestamp: "4 hours ago",
      likes: 156,
      comments: 24,
      liked: false,
    },
    {
      id: 3,
      author: "Maria Silva",
      avatar: "👩‍🔬",
      title: "ML Engineer | Python & TensorFlow",
      content:
        "Published my latest research paper on deep learning optimization techniques. Currently accepting collaborators for the next phase. Preprint available on arXiv!",
      timestamp: "1 day ago",
      likes: 342,
      comments: 42,
      liked: false,
    },
  ])

  const [postText, setPostText] = useState("")
  const [language, setLanguage] = useState("en")

  const languages = {
    en: { label: "English", name: "Name" },
    es: { label: "Spanish", name: "Nombre" },
    fr: { label: "French", name: "Nom" },
    de: { label: "German", name: "Name" },
  }

  const handlePost = () => {
    if (postText.trim()) {
      const newPost = {
        id: posts.length + 1,
        author: "You",
        avatar: "💻",
        title: "Developer",
        content: postText,
        timestamp: "now",
        likes: 0,
        comments: 0,
        liked: false,
      }
      setPosts([newPost, ...posts])
      setPostText("")
    }
  }

  const toggleLike = (id: number) => {
    setPosts(
      posts.map((post) =>
        post.id === id ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 } : post,
      ),
    )
  }

  const handlePostRateLimit = () => {
    alert("Rate limit: You can post once per minute")
  }

  const handleLogout = () => {
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 border-r border-border bg-card fixed h-screen hidden md:flex flex-col">
          <div className="p-6 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-primary-foreground font-bold text-sm">
                DM
              </div>
              <span className="font-bold text-lg">DevMatch</span>
            </div>
          </div>

          <nav className="flex-1 p-6 space-y-2">
            <Link href="/feed">
              <Button variant="ghost" className="w-full justify-start" size="lg">
                <Home className="w-5 h-5 mr-3" /> Feed
              </Button>
            </Link>
            <Link href="/resume">
              <Button variant="ghost" className="w-full justify-start" size="lg">
                <FileText className="w-5 h-5 mr-3" /> Resume Builder
              </Button>
            </Link>
            <Link href="/subscriptions">
              <Button variant="ghost" className="w-full justify-start" size="lg">
                <Zap className="w-5 h-5 mr-3" /> Premium
              </Button>
            </Link>
            <Link href="/settings">
              <Button variant="ghost" className="w-full justify-start" size="lg">
                <Settings className="w-5 h-5 mr-3" /> Settings
              </Button>
            </Link>
          </nav>

          <div className="p-6 border-t border-border space-y-2">
            <Button variant="outline" className="w-full justify-start bg-transparent" onClick={handleLogout}>
              <LogOut className="w-5 h-5 mr-3" /> Logout
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 md:ml-64">
          {/* Top Navigation */}
          <div className="border-b border-border bg-card/50 backdrop-blur sticky top-0 z-40">
            <div className="px-4 md:px-6 py-4 flex items-center justify-between">
              <div className="flex-1 max-w-md">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Search posts..." className="pl-10" />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="px-3 py-2 rounded-lg border border-border text-sm bg-background"
                >
                  {Object.entries(languages).map(([code, lang]) => (
                    <option key={code} value={code}>
                      {lang.label}
                    </option>
                  ))}
                </select>
                <Globe className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
          </div>

          <div className="max-w-2xl mx-auto py-6 px-4 md:px-6">
            {/* Create Post */}
            <div className="bg-card border border-border rounded-xl p-6 mb-6">
              <div className="space-y-4">
                <div className="text-lg font-semibold">Share Your Code & Ideas</div>
                <textarea
                  value={postText}
                  onChange={(e) => setPostText(e.target.value)}
                  placeholder="Share a code snippet, project update, or ask for help..."
                  className="w-full min-h-24 p-3 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                />
                <div className="flex gap-2">
                  <Button onClick={handlePost} disabled={!postText.trim()} className="flex-1">
                    <Plus className="w-4 h-4 mr-2" /> Post
                  </Button>
                  <Button variant="outline" onClick={handlePostRateLimit}>
                    Rate Limited
                  </Button>
                </div>
              </div>
            </div>

            {/* Posts Feed */}
            <div className="space-y-6">
              {posts.map((post) => (
                <div
                  key={post.id}
                  className="bg-card border border-border rounded-xl p-6 hover:border-border/80 transition-colors"
                >
                  <div className="flex gap-4 mb-4">
                    <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-xl">
                      {post.avatar}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold">{post.author}</div>
                      <div className="text-sm text-muted-foreground">{post.title}</div>
                      <div className="text-xs text-muted-foreground mt-1">{post.timestamp}</div>
                    </div>
                  </div>

                  <p className="text-foreground mb-4 leading-relaxed">{post.content}</p>

                  <div className="flex items-center gap-8 text-muted-foreground text-sm">
                    <button
                      onClick={() => toggleLike(post.id)}
                      className="flex items-center gap-2 hover:text-red-500 transition-colors"
                    >
                      <Heart className={`w-4 h-4 ${post.liked ? "fill-red-500 text-red-500" : ""}`} />
                      {post.likes}
                    </button>
                    <button className="flex items-center gap-2 hover:text-primary transition-colors">
                      <MessageCircle className="w-4 h-4" />
                      {post.comments}
                    </button>
                    <button className="flex items-center gap-2 hover:text-accent transition-colors">
                      <Share2 className="w-4 h-4" />
                      Share
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
