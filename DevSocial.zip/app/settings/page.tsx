"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { ArrowLeft, Shield, Bell, Eye, LogOut } from "lucide-react"

export default function Settings() {
  const [settings, setSettings] = useState({
    email: "user@example.com",
    language: "en",
    theme: "system",
    emailNotifications: true,
    twoFactor: false,
    profileVisibility: "public",
  })

  const [savedSettings, setSavedSettings] = useState({ ...settings })

  const handleSave = () => {
    setSavedSettings({ ...settings })
    alert("Settings saved successfully!")
  }

  const handleReset = () => {
    setSettings({ ...savedSettings })
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card/50 backdrop-blur sticky top-0">
        <div className="max-w-3xl mx-auto px-6 py-4 flex items-center">
          <Link href="/feed" className="flex items-center gap-2 text-primary hover:underline">
            <ArrowLeft className="w-4 h-4" /> Back to Feed
          </Link>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-6 py-8">
        <h1 className="text-3xl font-bold mb-8">Settings</h1>

        <div className="space-y-8">
          {/* Account Section */}
          <div className="bg-card border border-border rounded-lg p-6 space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Shield className="w-5 h-5" /> Account
            </h2>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Email Address</label>
                <Input
                  value={settings.email}
                  onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                  type="email"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Language</label>
                <select
                  value={settings.language}
                  onChange={(e) => setSettings({ ...settings, language: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground"
                >
                  <option value="en">English</option>
                  <option value="es">Spanish</option>
                  <option value="fr">French</option>
                  <option value="de">German</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Theme</label>
                <select
                  value={settings.theme}
                  onChange={(e) => setSettings({ ...settings, theme: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground"
                >
                  <option value="light">Light</option>
                  <option value="dark">Dark</option>
                  <option value="system">System</option>
                </select>
              </div>
            </div>
          </div>

          {/* Notifications Section */}
          <div className="bg-card border border-border rounded-lg p-6 space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Bell className="w-5 h-5" /> Notifications
            </h2>

            <div className="space-y-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.emailNotifications}
                  onChange={(e) => setSettings({ ...settings, emailNotifications: e.target.checked })}
                  className="w-4 h-4 rounded border-border"
                />
                <span>Email notifications</span>
              </label>

              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.twoFactor}
                  onChange={(e) => setSettings({ ...settings, twoFactor: e.target.checked })}
                  className="w-4 h-4 rounded border-border"
                />
                <span>Two-factor authentication</span>
              </label>
            </div>
          </div>

          {/* Privacy Section */}
          <div className="bg-card border border-border rounded-lg p-6 space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Eye className="w-5 h-5" /> Privacy
            </h2>

            <div className="space-y-2">
              <label className="text-sm font-medium">Profile Visibility</label>
              <select
                value={settings.profileVisibility}
                onChange={(e) => setSettings({ ...settings, profileVisibility: e.target.value })}
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground"
              >
                <option value="public">Public</option>
                <option value="private">Private</option>
                <option value="friends">Friends Only</option>
              </select>
            </div>
          </div>

          {/* Danger Zone */}
          <div className="bg-destructive/5 border border-destructive/20 rounded-lg p-6 space-y-4">
            <h2 className="text-lg font-semibold text-destructive flex items-center gap-2">
              <LogOut className="w-5 h-5" /> Danger Zone
            </h2>

            <Button variant="destructive" className="w-full">
              Delete Account
            </Button>
          </div>

          {/* Save Buttons */}
          <div className="flex gap-4 justify-end">
            <Button
              variant="outline"
              onClick={handleReset}
              disabled={JSON.stringify(settings) === JSON.stringify(savedSettings)}
            >
              Reset
            </Button>
            <Button onClick={handleSave} disabled={JSON.stringify(settings) === JSON.stringify(savedSettings)}>
              Save Settings
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
